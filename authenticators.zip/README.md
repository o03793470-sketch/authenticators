# authenticators

C/C++ authentication core with JSON configuration.
