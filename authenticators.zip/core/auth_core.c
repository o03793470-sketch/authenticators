#include "auth_core.h"
#include <string.h>

int auth_login(const char* username, const char* password, char* out_token) {
    if (!username || !password || !out_token) return -1;
    strcpy(out_token, "demo_token_123");
    return 0;
}

int auth_verify_token(const char* token) {
    if (!token) return -1;
    return strcmp(token, "demo_token_123") == 0 ? 0 : -1;
}
