#ifndef AUTH_CORE_H
#define AUTH_CORE_H

int auth_login(const char* username, const char* password, char* out_token);
int auth_verify_token(const char* token);

#endif
