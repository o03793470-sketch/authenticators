#pragma once
#include <string>

class Authenticator {
public:
    bool login(const std::string& user, const std::string& pass);
    std::string token() const;

private:
    std::string currentToken;
};
