#include "Authenticator.hpp"

bool Authenticator::login(const std::string& user, const std::string& pass) {
    if (user.empty() || pass.empty()) return false;
    currentToken = "demo_token_123";
    return true;
}

std::string Authenticator::token() const {
    return currentToken;
}
